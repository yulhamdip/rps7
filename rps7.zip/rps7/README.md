# RPS-7 Game

RPS-7（7 種類のじゃんけん）ゲームの RESTful API プロジェクトです。

## 🚀 Quick Start

### セットアップと起動

```bash
# 1. 依存関係のインストール
npm run install

# 2. サーバー起動
npm start
```

または開発モード（nodemon 使用）

```bash
npm run dev
```

### 🎮 ゲームをプレイ

サーバーが起動したら以下にアクセス：

- **API ドキュメント**: http://localhost:3000/
- **ゲームエンドポイント**: http://localhost:3000/api/game/play
- **ルール確認**: http://localhost:3000/api/game/rules

## 📁 プロジェクト構造 (MVC)

```
rps7/
├── 📄 package.json           ← Root scripts
├── 📄 logic.txt              ← アーキテクチャ説明
└── api/                      ← API アプリケーション
    ├── 📂 config/            ← Model: 設定とデータ
    │   └── gameConfig.js
    ├── 📂 models/            ← Model: ビジネスロジック
    │   └── rps7.js
    ├── 📂 controllers/       ← Controller: リクエスト処理
    │   └── game.js
    ├── 📂 public/            ← View: 静的ファイル
    │   └── index.html
    └── 📄 server.js          ← メインアプリケーション
```

## 🎯 API 使用方法

### ゲームプレイ

```bash
curl -X POST http://localhost:3000/api/game/play \
  -H "Content-Type: application/json" \
  -d '{"hand": "rock"}'
```

### 有効な手

- `rock` (グー)
- `scissors` (チョキ)
- `paper` (パー)
- `water` (ウォーター)
- `air` (エア)
- `sponge` (スポンジ)
- `fire` (ファイヤー)

## ⚙️ Scripts

- `npm start` - サーバー起動
- `npm run dev` - 開発モード（nodemon）
- `npm run install` - 依存関係インストール
- `npm test` - テスト実行

## 📊 ゲーム確率

- プレイヤー勝利: 40%
- プレイヤー敗北: 40%
- 引き分け: 20%

設定は `api/config/gameConfig.js` で変更可能です。
