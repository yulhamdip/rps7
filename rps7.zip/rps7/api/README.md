# RPS-7 API

RPS-7（7 種類のじゃんけん）ゲームの RESTful API です。

## セットアップ

1. 依存関係のインストール

```bash
cd api
npm install
```

2. サーバー起動

```bash
npm start
```

または開発モード（nodemon 使用）

```bash
npm run dev
```

## API 仕様

### ベース URL

```
http://localhost:3000
```

### エンドポイント

#### 1. ゲームプレイ

```
POST /api/game/play
Content-Type: application/json

{
  "hand": "rock"
}
```

**有効な手**: `rock`, `scissors`, `paper`, `water`, `air`, `sponge`, `fire`

**レスポンス例**:

```json
{
  "success": true,
  "data": {
    "playerHand": "rock",
    "computerHand": "scissors",
    "result": "win",
    "message": "あなたの勝ちです！"
  }
}
```

#### 2. ゲームルール取得

```
GET /api/game/rules
```

#### 3. API 状態確認

```
GET /api/game/status
```

#### 4. API 情報

```
GET /
```

## ゲームルール

RPS-7 は 7 種類の手でじゃんけんを行うゲームです：

- **グー (rock)**: ファイヤー・チョキ・スポンジに勝つ
- **ウォーター (water)**: グー・ファイヤー・チョキに勝つ
- **エア (air)**: ウォーター・グー・ファイヤーに勝つ
- **パー (paper)**: エア・ウォーター・グーに勝つ
- **スポンジ (sponge)**: パー・エア・ウォーターに勝つ
- **チョキ (scissors)**: スポンジ・パー・エアに勝つ
- **ファイヤー (fire)**: チョキ・スポンジ・パーに勝つ

## 確率設定

- プレイヤー勝利確率: 40%
- プレイヤー敗北確率: 40%
- 引き分け確率: 20%

確率は `config/gameConfig.js` で変更可能です。

## テスト例

curl を使用したテスト：

```bash
# ゲームプレイ
curl -X POST http://localhost:3000/api/game/play \
  -H "Content-Type: application/json" \
  -d '{"hand": "rock"}'

# ルール確認
curl http://localhost:3000/api/game/rules
```
