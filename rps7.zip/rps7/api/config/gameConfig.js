// ゲーム設定定数
const GAME_CONFIG = {
  // プレイヤーが勝利する確率（0.0 - 1.0）
  PLAYER_WIN_PROBABILITY: 0.4,
  
  // プレイヤーが敗北する確率（0.0 - 1.0）
  PLAYER_LOSE_PROBABILITY: 0.4,
  
  // 残りは引き分け（あいこ）となる
  // DRAW_PROBABILITY = 1.0 - WIN_PROBABILITY - LOSE_PROBABILITY = 0.2
};

// RPS-7の手の種類
const HANDS = {
  ROCK: 'rock',           // グー
  SCISSORS: 'scissors',   // チョキ
  PAPER: 'paper',         // パー
  WATER: 'water',         // ウォーター
  AIR: 'air',             // エア
  SPONGE: 'sponge',       // スポンジ
  FIRE: 'fire'            // ファイヤー
};

// 勝敗の結果
const RESULTS = {
  WIN: 'win',       // プレイヤー勝利
  LOSE: 'lose',     // プレイヤー敗北
  DRAW: 'draw'      // 引き分け（あいこ）
};

// 各手が勝つ手の関係性を定義
const WINNING_RELATIONSHIPS = {
  [HANDS.ROCK]: [HANDS.FIRE, HANDS.SCISSORS, HANDS.SPONGE],
  [HANDS.WATER]: [HANDS.ROCK, HANDS.FIRE, HANDS.SCISSORS],
  [HANDS.AIR]: [HANDS.WATER, HANDS.ROCK, HANDS.FIRE],
  [HANDS.PAPER]: [HANDS.AIR, HANDS.WATER, HANDS.ROCK],
  [HANDS.SPONGE]: [HANDS.PAPER, HANDS.AIR, HANDS.WATER],
  [HANDS.SCISSORS]: [HANDS.SPONGE, HANDS.PAPER, HANDS.AIR],
  [HANDS.FIRE]: [HANDS.SCISSORS, HANDS.SPONGE, HANDS.PAPER]
};

module.exports = {
  GAME_CONFIG,
  HANDS,
  RESULTS,
  WINNING_RELATIONSHIPS
};
