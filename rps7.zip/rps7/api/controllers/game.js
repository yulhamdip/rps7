const express = require('express');
const router = express.Router();
const RPS7Game = require('../models/rps7');

// RPS7ゲームのインスタンスを作成
const game = new RPS7Game();

/**
 * POST /api/game/play
 * RPS-7ゲームをプレイするエンドポイント
 */
router.post('/play', (req, res) => {
  try {
    const { hand } = req.body;
    
    // リクエストボディの検証
    if (!hand) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'hand parameter is required',
        validHands: ['rock', 'scissors', 'paper', 'water', 'air', 'sponge', 'fire']
      });
    }

    // ゲームをプレイ
    const result = game.playGame(hand);
    
    // 成功レスポンス
    res.status(200).json({
      success: true,
      data: result
    });
    
  } catch (error) {
    // エラーレスポンス
    res.status(400).json({
      error: 'Bad Request',
      message: error.message,
      validHands: ['rock', 'scissors', 'paper', 'water', 'air', 'sponge', 'fire']
    });
  }
});

/**
 * GET /api/game/rules
 * ゲームルールを取得するエンドポイント
 */
router.get('/rules', (req, res) => {
  res.status(200).json({
    success: true,
    data: {
      gameName: 'RPS-7 (Rock Paper Scissors 7)',
      description: 'アメリカ生まれの7種類の手でじゃんけんを行うゲーム',
      hands: [
        { name: 'rock', japanese: 'グー', defeats: ['fire', 'scissors', 'sponge'] },
        { name: 'water', japanese: 'ウォーター', defeats: ['rock', 'fire', 'scissors'] },
        { name: 'air', japanese: 'エア', defeats: ['water', 'rock', 'fire'] },
        { name: 'paper', japanese: 'パー', defeats: ['air', 'water', 'rock'] },
        { name: 'sponge', japanese: 'スポンジ', defeats: ['paper', 'air', 'water'] },
        { name: 'scissors', japanese: 'チョキ', defeats: ['sponge', 'paper', 'air'] },
        { name: 'fire', japanese: 'ファイヤー', defeats: ['scissors', 'sponge', 'paper'] }
      ],
      howToPlay: {
        endpoint: 'POST /api/game/play',
        body: { hand: 'rock' },
        validHands: ['rock', 'scissors', 'paper', 'water', 'air', 'sponge', 'fire']
      }
    }
  });
});

/**
 * GET /api/game/status
 * APIの状態を取得するエンドポイント
 */
router.get('/status', (req, res) => {
  res.status(200).json({
    success: true,
    data: {
      status: 'running',
      version: '1.0.0',
      timestamp: new Date().toISOString()
    }
  });
});

module.exports = router;
