const { GAME_CONFIG, HANDS, RESULTS, WINNING_RELATIONSHIPS } = require('../config/gameConfig');

class RPS7Game {
  constructor() {
    this.hands = Object.values(HANDS);
  }

  /**
   * プレイヤーの手を検証
   * @param {string} playerHand - プレイヤーの手
   * @returns {boolean} - 有効な手かどうか
   */
  validatePlayerHand(playerHand) {
    return this.hands.includes(playerHand.toLowerCase());
  }

  /**
   * 2つの手の間の勝敗を判定
   * @param {string} hand1 - 手1
   * @param {string} hand2 - 手2
   * @returns {string} - hand1から見た結果 ('win', 'lose', 'draw')
   */
  determineWinner(hand1, hand2) {
    if (hand1 === hand2) {
      return RESULTS.DRAW;
    }
    
    if (WINNING_RELATIONSHIPS[hand1].includes(hand2)) {
      return RESULTS.WIN;
    }
    
    return RESULTS.LOSE;
  }

  /**
   * 確率に基づいてコンピューターの手を決定
   * @param {string} playerHand - プレイヤーの手
   * @returns {object} - {computerHand: string, result: string}
   */
  generateComputerMove(playerHand) {
    const random = Math.random();
    
    // プレイヤーが勝利する確率
    if (random < GAME_CONFIG.PLAYER_WIN_PROBABILITY) {
      return this.generateWinningMove(playerHand);
    }
    
    // プレイヤーが敗北する確率
    if (random < GAME_CONFIG.PLAYER_WIN_PROBABILITY + GAME_CONFIG.PLAYER_LOSE_PROBABILITY) {
      return this.generateLosingMove(playerHand);
    }
    
    // 引き分け（あいこ）
    return {
      computerHand: playerHand,
      result: RESULTS.DRAW
    };
  }

  /**
   * プレイヤーが勝利するコンピューターの手を生成
   * @param {string} playerHand - プレイヤーの手
   * @returns {object} - {computerHand: string, result: string}
   */
  generateWinningMove(playerHand) {
    // プレイヤーの手が勝つ手の中からランダムに選択
    const losingHands = WINNING_RELATIONSHIPS[playerHand];
    const computerHand = losingHands[Math.floor(Math.random() * losingHands.length)];
    
    return {
      computerHand,
      result: RESULTS.WIN
    };
  }

  /**
   * プレイヤーが敗北するコンピューターの手を生成
   * @param {string} playerHand - プレイヤーの手
   * @returns {object} - {computerHand: string, result: string}
   */
  generateLosingMove(playerHand) {
    // プレイヤーの手を負かす手を見つける
    const winningHands = [];
    
    for (const [hand, defeats] of Object.entries(WINNING_RELATIONSHIPS)) {
      if (defeats.includes(playerHand)) {
        winningHands.push(hand);
      }
    }
    
    const computerHand = winningHands[Math.floor(Math.random() * winningHands.length)];
    
    return {
      computerHand,
      result: RESULTS.LOSE
    };
  }

  /**
   * ゲームをプレイ
   * @param {string} playerHand - プレイヤーの手
   * @returns {object} - ゲーム結果
   */
  playGame(playerHand) {
    // 入力検証
    if (!this.validatePlayerHand(playerHand)) {
      throw new Error(`Invalid hand: ${playerHand}. Valid hands are: ${this.hands.join(', ')}`);
    }

    const normalizedPlayerHand = playerHand.toLowerCase();
    
    // コンピューターの手と結果を生成
    const { computerHand, result } = this.generateComputerMove(normalizedPlayerHand);
    
    return {
      playerHand: normalizedPlayerHand,
      computerHand,
      result,
      message: this.getResultMessage(result)
    };
  }

  /**
   * 結果に応じたメッセージを取得
   * @param {string} result - ゲーム結果
   * @returns {string} - 結果メッセージ
   */
  getResultMessage(result) {
    switch (result) {
      case RESULTS.WIN:
        return 'あなたの勝ちです！';
      case RESULTS.LOSE:
        return 'あなたの負けです！';
      case RESULTS.DRAW:
        return 'あいこです！';
      default:
        return '不明な結果です。';
    }
  }
}

module.exports = RPS7Game;
