const handEmojis = {
    'rock': '🪨',
    'scissors': '✂️',
    'paper': '📄',
    'water': '💧',
    'air': '💨',
    'sponge': '🧽',
    'fire': '🔥'
};

const handNames = {
    'rock': 'グー',
    'scissors': 'チョキ',
    'paper': 'パー',
    'water': 'ウォーター',
    'air': 'エア',
    'sponge': 'スポンジ',
    'fire': 'ファイヤー'
};

// Game statistics
let gameStats = {
    wins: 0,
    losses: 0,
    draws: 0,
    total: 0
};

// Load stats from localStorage
function loadStats() {
    const saved = localStorage.getItem('rps7-stats');
    if (saved) {
        gameStats = JSON.parse(saved);
        updateStatsDisplay();
    }
}

// Save stats to localStorage
function saveStats() {
    localStorage.setItem('rps7-stats', JSON.stringify(gameStats));
}

// Update stats display
function updateStatsDisplay() {
    document.getElementById('wins').textContent = gameStats.wins;
    document.getElementById('losses').textContent = gameStats.losses;
    document.getElementById('draws').textContent = gameStats.draws;
    document.getElementById('total').textContent = gameStats.total;
}

async function playGame(hand) {
    // Add loading state
    const buttons = document.querySelectorAll('.hand-button');
    buttons.forEach(btn => {
        btn.style.pointerEvents = 'none';
        btn.style.opacity = '0.6';
    });

    try {
        const response = await fetch('/api/game/play', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ hand: hand })
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayResult(data.data);
            updateStats(data.data.result);
        } else {
            displayError(data.message);
        }
    } catch (error) {
        displayError('サーバーとの通信に失敗しました: ' + error.message);
    } finally {
        // Remove loading state
        buttons.forEach(btn => {
            btn.style.pointerEvents = 'auto';
            btn.style.opacity = '1';
        });
    }
}

function updateStats(result) {
    gameStats.total++;
    switch (result) {
        case 'win':
            gameStats.wins++;
            break;
        case 'lose':
            gameStats.losses++;
            break;
        case 'draw':
            gameStats.draws++;
            break;
    }
    updateStatsDisplay();
    saveStats();
}

function displayResult(result) {
    const resultSection = document.getElementById('result');
    const playerEmoji = document.getElementById('player-emoji');
    const computerEmoji = document.getElementById('computer-emoji');
    const playerChoice = document.getElementById('player-choice');
    const computerChoice = document.getElementById('computer-choice');
    const resultMessage = document.getElementById('result-message');
    
    // Update battle display
    playerEmoji.textContent = handEmojis[result.playerHand];
    computerEmoji.textContent = handEmojis[result.computerHand];
    playerChoice.textContent = handNames[result.playerHand];
    computerChoice.textContent = handNames[result.computerHand];
    
    // Update result message
    resultMessage.textContent = result.message;
    resultMessage.className = `result-message ${result.result}`;
    
    // Show result section with animation
    resultSection.style.display = 'block';
    resultSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function displayError(message) {
    const resultSection = document.getElementById('result');
    const resultMessage = document.getElementById('result-message');
    
    resultMessage.innerHTML = `<i class="fas fa-exclamation-triangle"></i> エラー: ${message}`;
    resultMessage.className = 'result-message lose';
    
    resultSection.style.display = 'block';
    resultSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Initialize stats on page load
document.addEventListener('DOMContentLoaded', function() {
    loadStats();
    
    // Add hover effects to hand buttons
    const handButtons = document.querySelectorAll('.hand-button');
    handButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Add ripple effect
    handButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('div');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                background: rgba(102, 126, 234, 0.3);
                border-radius: 50%;
                transform: scale(0);
                animation: ripple 0.6s ease-out;
                pointer-events: none;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });
});
