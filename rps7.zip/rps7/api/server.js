const express = require('express');
const cors = require('cors');
const gameRoutes = require('./controllers/game');

// Expressアプリケーションを作成
const app = express();
const PORT = process.env.PORT || 3000;

// ミドルウェアの設定
app.use(cors()); // CORS有効化
app.use(express.json()); // JSONパーサー
app.use(express.urlencoded({ extended: true })); // URLエンコードパーサー

// 静的ファイルの提供
app.use(express.static('public'));

// ルートの設定
app.use('/api/game', gameRoutes);

// ルートエンドポイント
app.get('/', (req, res) => {
  res.json({
    message: 'RPS-7 API Server',
    description: 'RESTful API for RPS-7 (7-hand rock-paper-scissors) game',
    version: '1.0.0',
    endpoints: {
      'POST /api/game/play': 'Play RPS-7 game',
      'GET /api/game/rules': 'Get game rules',
      'GET /api/game/status': 'Get API status'
    },
    documentation: {
      gameUrl: 'http://www.umop.com/rps7.htm',
      howToPlay: {
        method: 'POST',
        url: '/api/game/play',
        body: { hand: 'rock' },
        validHands: ['rock', 'scissors', 'paper', 'water', 'air', 'sponge', 'fire']
      }
    }
  });
});

// 404エラーハンドリング
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.originalUrl} not found`,
    availableEndpoints: [
      'GET /',
      'POST /api/game/play',
      'GET /api/game/rules',
      'GET /api/game/status'
    ]
  });
});

// エラーハンドリングミドルウェア
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: 'Something went wrong!'
  });
});

// サーバー起動
app.listen(PORT, () => {
  console.log(`🎮 RPS-7 API Server is running on port ${PORT}`);
  console.log(`📖 API Documentation: http://localhost:${PORT}/`);
  console.log(`🎯 Game Endpoint: http://localhost:${PORT}/api/game/play`);
  console.log(`📋 Rules Endpoint: http://localhost:${PORT}/api/game/rules`);
});

module.exports = app;
